#ifndef USER_H
#define USER_H
#include <string>
#include <cctype>
#include <iostream>
using namespace std;
namespace Authenticate
{
	void inputUserName();
	string getUserName();
}
#endif