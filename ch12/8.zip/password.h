#ifndef PASSWORD_H
#define PASSWORD_H
#include <string>
#include <cctype>
#include <iostream>
using namespace std;
namespace Authenticate
{
	void inputPassword();
	string getPassword();
}
#endif
