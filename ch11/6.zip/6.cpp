#include <cmath>
#include <iostream>
#include "complex.h"
using namespace std;
int main()
{
	// test1
	Complex t1,t2(2),t3(1.2,3.4), t4(-5.6,7.8);
	cout<<"t1"<<t1<<"\nt2"<<t2<<"\nt3"<<t3<<"\nt4"<<t4;
	//test1 end
	//tets2
	Complex t5;
	t5 = Complex(-6, 7);

	cout<< t5 <<"\n"<< t5.real() <<"\n"<< t5.imag() <<"\n"<< real(t5) <<"\n"<< imag(t5) <<"\n"<< normalize_no(t5);
	//tets2 end
	//test3
	Complex t6, t7;
	t5 = Complex(5, -6);
	t6 = Complex(1,2);
	cout << "\n" << t5 << "\n" << t6<<"\n"<<t7;
	//+-*/
	t7 = t5 + t6;
	cout << "\nt7 = t5 + t6;" <<t7;
	t7 = t5 - t6;
	cout << "t7 = t5 - t6 = " << t7 <<"\n";
	t7 = t5 * t6;
	cout << "t7 = t5 * t6 = " << t7 <<"\n";
	t7 = t5 / t6;
	cout << "t7 = t5 / t6 = " << t7 <<"\n";



	double tt1(2.0);
	cout << "tt1: " << tt1 << "  t5: " <<t5 <<endl;
	cout << "t5+tt1: " ;
	t7 =t5 + tt1;
	cout << t7 <<"\n";
	t7 = t5 - tt1;
	cout << "t5-tt1: " ;
	cout << t7 <<"\n";
	t7 = t5 * tt1;
	cout << "t5*tt1: ";
	cout << t7 <<"\n";
	t7 = t5 / tt1;
	cout << "t5/tt1: " ;
	cout << t7 <<"\n";
	return 0;
}

