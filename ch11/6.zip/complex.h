#ifndef COMPPLEX_h
#define COMPPLEX_h
#include <cmath>
#include <iostream>
using namespace std;
class Complex
{
public:
	Complex(double r = 0, double i = 0)
		: re(r), im(i){}

	double real () const
	{ return re; }
	double imag () const 
	{ return im; }

	friend double real (const Complex&) ;
	friend double imag (const Complex&)  ;
	//bool
	friend bool operator == (const Complex&, const Complex&);
	//+-*/
	friend Complex operator + (const Complex&, const Complex&);
	friend Complex operator - (const Complex&,	const Complex&);
	friend Complex operator * (const Complex&, const Complex&);
	friend Complex operator / (const Complex&, const Complex&);
	//>><<
	friend istream& operator>> (istream&, Complex&);
	friend ostream& operator<< (ostream&, const Complex&);
private:
	double re, im;
};
double normalize_no (const Complex& t)  
{
	return real (t) * real (t) + imag (t) * imag (t);
}
istream& operator>> (istream& cin, Complex& tt) 
{
	double r, i;
	char temp;

	cin >> temp;
	if ('(' != temp)
	{
		cout << "error 1";
		exit(1);
	}

	cin>> r;

	cin>>temp;
	if ('(' != temp)
	{
		cout << "error 11";
		exit(11);
	}

	cin >> i;

	cin>>temp;
	if ('(' != temp)
	{
		cout << "error 111";
		exit(111);
	}
	tt = Complex(r, i);
	return cin;
}

ostream& operator<< (ostream& out, const Complex& t)
{ 
	out << "(" << t.re << ", " << t.im << ")"; 
	return out;
}


double real (const Complex& x)  
{
	return x.real ();
}
double imag (const Complex& x)  
{
	return x.imag ();
}

bool operator == (const Complex& x, const Complex& y)  
{
	return real (x) == real (y) && imag (x) == imag (y);
}

Complex operator + (const Complex& x, const Complex& y)  
{
	return Complex (real (x) + real (y), imag (x) + imag (y));
}

Complex operator - (const Complex& x, const Complex& y)
{
	return Complex (real (x) - real (y), imag (x) - imag (y));
}

Complex operator * (const Complex& x, const Complex& y)  
{
	return Complex (real (x) * real (y) - imag (x) * imag (y),real (x) * imag (y) + imag (x) * real (y));
}

Complex operator / (const Complex& x, double y)  
{
	return Complex (real (x) / y, imag (x) / y);
}


double abs (const Complex& x)  
{
	return sqrt(normalize_no(x));
}

Complex conj (const Complex& x)   
{
	return Complex (real (x), -imag (x));
}

Complex operator / (const Complex& num, const Complex& den)
{
	return(num * conj(den) * (1/normalize_no(den))); 
}
#endif